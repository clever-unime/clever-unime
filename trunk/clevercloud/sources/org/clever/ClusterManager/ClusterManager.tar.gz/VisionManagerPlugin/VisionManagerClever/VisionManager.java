/*
 * The MIT License
 *
 * Copyright 2012 s89.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.clever.ClusterManager.VisionManagerPlugin.VisionManagerClever;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import org.clever.ClusterManager.VisionManager.VisionManagerAgent;
import org.clever.ClusterManager.VisionManager.VisionManagerPlugin;
import org.clever.Common.Communicator.Agent;
import org.clever.Common.Exceptions.CleverException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;





/**
 *
 * @author s89
 */
class ClusterBuildThread extends VisionManager implements Runnable 
{   private String  name_cl;
    private int n_vms;
    private int n_netinterface;
    private String gold_name;
    private String name_bridge;
    private Logger logger;
    private String name_vm;
    private List VisionVmInfo;
    private int n_cl;
    private String ip;
    private String staticIp;
    private String mac;
    Agent owner;
    public ClusterBuildThread(int n_cl,String cl,int n_vms,int n_netinterface,String gold_name,String name_bridge,Logger l,String ip,Agent owner)
    {   this.gold_name=gold_name;
        this.n_vms=n_vms;
        this.n_netinterface=n_netinterface;
        this.name_cl=cl;
        this.name_bridge=name_bridge;
        logger=l;
        this.n_cl=n_cl;
        this.ip=ip;
        this.owner=owner;
        
    }
    @Override
    public void run(){
      try{
  //do what you want to do before sleeping
  Thread.currentThread().sleep(30000);//sleep for 1000 ms
  //do what you want to do after sleeptig
}
    catch(InterruptedException ie){
//If this thread was intrrupted by nother thread
} 
     logger.info("salvo89 dentro la run");
     
    int i,j;
    List vms=new ArrayList();
    List params=new ArrayList();
    
    for(i=0;i<n_vms;i++){
        name_vm=name_cl+"."+(i+1);
        VisionVmInfo vmi=new VisionVmInfo(name_vm);
        params.add(gold_name);
        params.add(name_vm);
        params.add("");
        params.add(name_cl);
        try {
             this.owner.invoke( "VirtualizationManagerAgent","TakeEasySnapshot", true, params);
             params.clear();
             logger.info("vm "+name_vm+" created");
             for(j=0;j<n_netinterface;j++){
                 params.add(name_vm);
                 params.add(name_bridge);
                 mac=macCalculator(n_cl,n_vms,j);
                 params.add(mac);
                 params.add("bridge");
                 this.owner.invoke("VirtualizationManagerAgent","attackInterface", true, params);
                 params.clear();
                 logger.info("interface number "+(j+1)+"attached");
                 //staticIp=getStatiIp(ip);
                 //this.owner.invoke("Virtualization","staticIpconfigurator", true, params);
                 vmi.addNetInterface(ip,mac);
                 vms.add(vmi);
                 ip=IpRange.getNextIp(ip);
                 logger.info("vm "+name_vm+" succesfully setted");
                }
                 
                 
                 
                
             
        }catch (CleverException ex) {
                logger.error("Error", ex);
             }       
        }
        
        
        //addClusterDb(name_cl,gold_name,vms);
                
         }
       
    }




public class VisionManager implements VisionManagerPlugin {
    protected Agent owner;
    private Logger logger;
    private Document doc;
    private String cfgpath;
     
    
    public VisionManager(){
       logger = Logger.getLogger("VisionManagerPlugin");
       cfgpath=System.getProperty("user.dir")+"vision/vision.cfg";
       logger.debug("Vision plugin created!");  
    }
    
    public static String macCalculator(int cl, int host,int inter){
    
    StringBuilder sb = new StringBuilder();
    sb.append(String.format("%s%s",52,":"));
    sb.append(String.format("%s%s",54,":"));
    sb.append(String.format("%02x%s",inter,":"));
    sb.append(String.format("%01x",cl));
    sb.append(String.format("%01x%s",0,":"));
    sb.append(String.format("%02x%s",0,":"));
    sb.append(String.format("%02x",host));
    return sb.toString();
    }
    public void prova(){
        logger.info("salvo89 dentro prova");
        ClusterBuildThread r= new ClusterBuildThread(1,"salvo1",3,2,"libvirt2","br0",logger,"192.168.1.23",this.owner);
        Thread t=new Thread(r);
        t.start();
    }
    public void setOwner(Agent owner) {
        this.owner=owner;
    }
    
    public Document loadConfiguration(){
        
        try {
            SAXBuilder builder=new SAXBuilder();
            doc=builder.build(cfgpath);
            return doc;
        } catch (JDOMException ex) {
            logger.error("Error"+ex);
        } catch (IOException ex) {
            logger.error("Error"+ex);   
        }
        return doc;
    }
   

    @Override
    public String getName() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String getVersion() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String getDescription() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void init(Element params, Agent owner) throws CleverException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
    
